import math
import random
import matplotlib.pyplot as plt



def readfile(filename):
    inp=[]
    with open(filename, encoding="utf8", errors='ignore') as fh:
         for line in fh:
             line = line.rstrip()
             res=line.split(' ')
             temp=[]
             for i in range(len(res)):
                 res[i]=res[i].lstrip()
                 temp.append(res[i])
             inp.append(temp)
    return inp

def randquery(inp):
    query=[]
    for i in range(100):
        a=random.randint(0,1000000)
        # print(a)
        query.append(inp[a])
    return query


def L1(a,b):
    distt=0.0
    for i in range(len(a)):
        distt+=abs(float(a[i])-float(b[i]))
    return distt

def L2(a,b):
    dist=0
    for i in range(len(a)):
        dist+=(abs(float(a[i])-float(b[i]))*abs(float(a[i])-float(b[i])))
    return math.sqrt(dist)

def Linf(a,b):
    dist=0
    for i in range(len(a)):
        diff=0
        diff=abs(float(a[i])-float(b[i]))
        if diff > dist:
            dist = diff
    return dist

def querycalc(query,inp):
    
    L1ratio=[]
    L2ratio=[]
    Linfratio=[]
    for i in range(len(query)):
        min1=100000.000
        max1=0
        minl=10000.0
        maxl=0
        mini=100000.0
        maxi=0
        for item2 in inp:
            item=query[i]
            
            if item==item2:
                continue
            else:
                temp=L1(item,item2)
                if temp>max1:
                    max1=temp
                if temp<min1:
                    min1=temp  
                temp1=L2(item,item2)  
                if temp1 > maxl:
                    maxl=temp1
                if temp1 < minl:
                    minl=temp1
                temp2=Linf(item,item2)
                if temp2 > maxi:
                    maxi=temp2
                if temp2 < mini:
                    mini=temp2 

         
        rtl=max1/min1
        L1ratio.append(rtl)
        rtl2=maxl/minl
        L2ratio.append(rtl2)
        rtli=maxi/mini
        Linfratio.append(rtli)
    return (L1ratio,L2ratio,Linfratio)





name=['d_1.txt','d_2.txt','d_4.txt','d_8.txt','d_16.txt','d_32.txt','d_64.txt']
L1c=list()
L2c=list()
Lic=list()
dim=[1,2,4,8,16,32,64]
for file in name:
    inp=readfile(file)
    query=randquery(inp)
    (a,b,c)=querycalc(query,inp)
    avgL1=math.log(sum(a)/100)
    avgL2=math.log(sum(b)/100)
    avgLinf=math.log(sum(c)/100)
    fh=open("output.txt",'a')
    fh.write(str(avgL1)+' '+str(avgL2)+' '+str(avgLinf))
    fh.write('\n')
    L1c.append(avgL1)
    L2c.append(avgL2)
    Lic.append(avgLinf)
    
plt.plot(dim,L1c,'r-',label='L1 distance')
plt.plot(dim,L2c,'b-',label='L2 distance')
plt.plot(dim,Lic,'c-',label='Linf Distance')
plt.xlabel('dimensions')
plt.ylabel('distance')
plt.legend()
plt.show()









