import numpy as np
import math
import random


def generator(d):
    inp=[]
    for i in range(1000000):
        temp=[]
        for j in range(d):
            a=random.random()
            temp.append(a)
        inp.append(temp)
    return inp
    
dimenshions=[1,2,4,8,16,32,64]
for dim in dimenshions:
    inp=generator(dim)
    name='d_'+str(dim)+'.txt'

    file=open(name,'w')
    for i in range(len(inp)):
        temp=inp[i]
        s=''
        for k in temp:
            file.write("%s \t" % k)
        file.write('\n')
    file.close()




            

