python3 dim.py
python3 Q1.py
