import numpy as np
import falconn
import timeit
import math
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

dataset = list()
d2 = list()
d4 = list()
d8 = list()
d10 = list()
dim = dict()
dim_reduction = [2,4,8,10]
avg_time = list()
inspections = list()

number_of_queries = 100
number_of_tables = 50

print('Reading the dataset')
with open('image_data.dat', encoding="utf8", errors='ignore') as fh1:
    for line in fh1:
            inp1 = list()             
            line = line.rstrip()
            res=line.split(' ')
            if len(res) > 0:
                    for i in res:
                        inp1.append(float(i))
            dataset.append(inp1)

dataset = np.array(dataset)
print('Done')

# PCA implementation

pca2 = PCA(n_components=2)
pca2.fit(dataset)
d2 = pca2.transform(dataset)

pca4 = PCA(n_components=4)
pca4.fit(dataset)
d4 = pca4.transform(dataset)

pca8 = PCA(n_components=8)
pca8.fit(dataset)
d8 = pca8.transform(dataset)

pca10 = PCA(n_components=10)
pca10.fit(dataset)
d10 = pca10.transform(dataset)

dim[2]  = d2
dim[4]  = d4
dim[8]  = d8
dim[10] = d10

for key in dim:
    dataset = dim[key]
    print('Normalizing the dataset')
    dataset /= np.linalg.norm(dataset, axis=1).reshape(-1, 1)

    print('Done')

    # Choose random data points to be queries.
    print('Generating queries')
    np.random.seed(4057218)
    np.random.shuffle(dataset)
    queries = dataset[len(dataset) - number_of_queries:]
    dataset = dataset[:len(dataset) - number_of_queries]
    print('Done')

    # Perform linear scan using NumPy to get answers to the queries.
    print('Solving queries using linear scan')
    answers = []
    for query in queries:
        answers.append(np.dot(dataset, query).argmax())
    print('Done')

    # Center the dataset and the queries: this improves the performance of LSH quite a bit.
    center = np.mean(dataset, axis=0)
    dataset -= center
    queries -= center

    params_cp = falconn.LSHConstructionParameters()
    params_cp.dimension = len(dataset[0])
    params_cp.lsh_family = falconn.LSHFamily.CrossPolytope
    params_cp.distance_function = falconn.DistanceFunction.EuclideanSquared
    params_cp.l = number_of_tables
    params_cp.num_rotations = 1
    params_cp.seed = 5721840
    params_cp.num_setup_threads = 0
    params_cp.storage_hash_table = falconn.StorageHashTable.BitPackedFlatHashTable
    falconn.compute_number_of_hash_functions(19, params_cp)

    print('Constructing the LSH table')
    t1 = timeit.default_timer()
    table = falconn.LSHIndex(params_cp)
    table.setup(dataset)
    t2 = timeit.default_timer()
    print('Done')
    print('Construction time: {}'.format(t2 - t1))

    query_object = table.construct_query_object()

    # find the smallest number of probes to achieve accuracy 0.9
    # using the binary search
    print('Choosing number of probes')
    number_of_probes = number_of_tables

    def evaluate_number_of_probes(number_of_probes):
        query_object.set_num_probes(number_of_probes)
        score = 0
        for (i, query) in enumerate(queries):
            if answers[i] in query_object.get_candidates_with_duplicates(
                    query):
                score += 1
        return float(score) / len(queries)

    while True:
        accuracy = evaluate_number_of_probes(number_of_probes)
        print('{} -> {}'.format(number_of_probes, accuracy))
        if accuracy >= 0.9:
            break
        number_of_probes = number_of_probes * 2
    if number_of_probes > number_of_tables:
        left = number_of_probes // 2
        right = number_of_probes
        while right - left > 1:
            number_of_probes = (left + right) // 2
            accuracy = evaluate_number_of_probes(number_of_probes)
            print('{} -> {}'.format(number_of_probes, accuracy))
            if accuracy >= 0.9:
                right = number_of_probes
            else:
                left = number_of_probes
        number_of_probes = right
    print('Done')
    print('{} probes'.format(number_of_probes))

    # final evaluation
    tlist = list()
    tcoll = list()
    for (i, query) in enumerate(queries):
        tcoll.append(len(query_object.get_unique_candidates(query)))

    coll_avg = sum(tcoll)/len(queries)
    inspections.append(coll_avg)    
    score = 0
    for (i, query) in enumerate(queries):
        t1 = timeit.default_timer()
        if query_object.find_k_nearest_neighbors(query,1) == answers[i]:
            score += 1
        t2 = timeit.default_timer()
        tlist.append(t2-t1)
    
   
    tavg = sum(tlist)/len(queries)
    avg_time.append(tavg)
    
    print('Inspections: {}'.format(coll_avg))
    print('Query time: {}'.format(tavg))

plt1=plt.figure(1)
plt.plot(dim_reduction,avg_time,color='green')
plt.xlabel('Dimensions')
plt.ylabel('Running time (seconds)')
plt.title('Running time vs Dimensions')
plt.legend()
plt2=plt.figure(2)
plt.plot(dim_reduction,inspections)
plt.xlabel('Dimensions')
plt.ylabel('No. of inspections')
plt.title('No. of inspections vs Dimensions')
plt.legend()
plt.show()
