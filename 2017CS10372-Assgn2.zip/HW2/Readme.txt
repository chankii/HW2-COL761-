﻿                                                COL 761 
                                                HW - 2


Q2.  -> We have written three files each corresponding to a,b and c part respectively.
Files lsh_2a.py, lsh_2b.py and lsh_2c.py correspond to each part of the second question and on running these files on the dataset file image_data.dat generates two separate plots one for running time and one for number of inspections against the respective metric of each part. These files only generate the plot for the LSH technique. If any other dataset file is considered for running the code and generating the respective plots then that file name has to be modified in all the three code files.
In all the three py files we are reading the dataset file and the name of the file has been hardcoded to image_data.dat so if any other file is being considered for reading the data other than this then this name has to be changed in all the py files. There is a print statement “Reading the dataset” below which the file name can be found and it can be changed accordingly.


Command to run the code files :- 
 lsh_2a.py ->  python3 lsh_2a.py
 lsh_2b.py -> python3 lsh_2b.py
 lsh_2c.py -> python3 lsh_2c.py


Command for running all 3 file together:
./run2.sh




Q1.


Files: 
        dim.py , Q1.py


dim.py-> this file generates the dataset of given dimensions which are [1,2,4,8,16,32,64] and write them in a file name d_x.txt here x can be any dimension from the dim list.


Q1.py-> This is the main code file where we have done our computations for the distances. And write it in file name output.txt
The format of output.txt is 
L1distance            L2distance                 LinfDistance


First row is for dim=1 followed by 2 4 8 16 32 64 respectively


Commands for running the code: 


./run1.sh