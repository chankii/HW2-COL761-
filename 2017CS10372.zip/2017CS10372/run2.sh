python3 lsh_2a.py
python3 lsh_2b.py
python3 lsh_2c.py

