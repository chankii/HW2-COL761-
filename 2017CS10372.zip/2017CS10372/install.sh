git clone https://github.com/chankii/HW2-COL761-.git
pip3 install -U numpy matplotlib sys random scipy scikit-learn itertools heapq time random
